package CreditcardDotcomTestSuite;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

/**
 *  Created by Isaac Coltrain on 2/7/2019
 *  Tests navigating the header's hover element for 'Card Category', the hover element of the sub-menu item -
 *  'Best Credit Cards', and the click action on 'Best Credit Cards.
 */
public class case3 {

    @Test
    public static void main(String[] args) {

        WebDriver driver=new ChromeDriver();

        driver.manage().window().maximize();

        //Enter Site URL.
        driver.get("https://www.creditcards.com");

        WebElement ele;

        //Enter xpath of element.
        ele = driver.findElement(By.xpath("//a[contains(text(),'Card category')]"));

        Actions act=new Actions(driver);

        act.moveToElement(ele).perform();


        //Enter xpath of element.
        driver.findElement(By.xpath("//a[text()='Best Credit Cards']")).click();

    }


}


