package CreditcardDotcomTestSuite;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

/**
 *  Created by Isaac Coltrain on 2/7/2019
 *  Tests navigating to the homepage of CreditCards.com to endure there are no connection errors.
 */
public class case1 {

    @Test(invocationCount = 100)

    public void WebDriver () {

        System.setProperty("webdriver.chrome.driver", "chromedriver");

        ChromeDriver driver;

        driver = new ChromeDriver();

        //Enter site URL.
        driver.navigate().to("https://www.creditcards.com");

        driver.close();


    }

}
